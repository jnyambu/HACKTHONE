import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Recipe } from '@/data/recipes';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipe: Recipe | null;
}

export default function OrderModal({ isOpen, onClose, recipe }: OrderModalProps) {
  const [orderData, setOrderData] = useState({
    name: '',
    email: '',
    phone: '',
    quantity: '1',
    deliveryDate: '',
    specialInstructions: '',
    questions: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Order placed successfully for ${recipe?.name}! We'll contact you soon with details.`);
    onClose();
    setOrderData({
      name: '',
      email: '',
      phone: '',
      quantity: '1',
      deliveryDate: '',
      specialInstructions: '',
      questions: ''
    });
  };

  if (!recipe) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Order {recipe.name}</DialogTitle>
          <DialogDescription>
            Fill out the form below to place your order. We'll prepare everything for you!
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-blue-50 p-3 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium">{recipe.name}</span>
              <span className="text-sm text-gray-600">{recipe.difficulty} Level</span>
            </div>
            <div className="text-sm text-gray-600">
              Serves {recipe.servings} • {recipe.cookTime} • ${recipe.price} per order
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={orderData.name}
                onChange={(e) => setOrderData({...orderData, name: e.target.value})}
                required
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone Number *</Label>
              <Input
                id="phone"
                type="tel"
                value={orderData.phone}
                onChange={(e) => setOrderData({...orderData, phone: e.target.value})}
                required
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="email">Email Address *</Label>
            <Input
              id="email"
              type="email"
              value={orderData.email}
              onChange={(e) => setOrderData({...orderData, email: e.target.value})}
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="quantity">Quantity</Label>
              <Select value={orderData.quantity} onValueChange={(value) => setOrderData({...orderData, quantity: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Order</SelectItem>
                  <SelectItem value="2">2 Orders</SelectItem>
                  <SelectItem value="3">3 Orders</SelectItem>
                  <SelectItem value="4">4 Orders</SelectItem>
                  <SelectItem value="5">5+ Orders</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="deliveryDate">Preferred Date</Label>
              <Input
                id="deliveryDate"
                type="date"
                value={orderData.deliveryDate}
                onChange={(e) => setOrderData({...orderData, deliveryDate: e.target.value})}
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="specialInstructions">Special Instructions</Label>
            <Textarea
              id="specialInstructions"
              placeholder="Any dietary restrictions, allergies, or special requests..."
              value={orderData.specialInstructions}
              onChange={(e) => setOrderData({...orderData, specialInstructions: e.target.value})}
            />
          </div>
          
          <div>
            <Label htmlFor="questions">Questions or Comments</Label>
            <Textarea
              id="questions"
              placeholder="Ask us anything about the recipe, ingredients, or cooking process..."
              value={orderData.questions}
              onChange={(e) => setOrderData({...orderData, questions: e.target.value})}
            />
          </div>
          
          <div className="bg-gray-50 p-3 rounded-lg">
            <div className="flex justify-between items-center">
              <span>Total Amount:</span>
              <span className="font-bold text-lg">
                ${(parseFloat(recipe.price.toString()) * parseInt(orderData.quantity)).toFixed(2)}
              </span>
            </div>
            <div className="text-xs text-gray-600 mt-1">
              Includes all ingredients, recipe card, and cooking instructions
            </div>
          </div>
          
          <div className="flex gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              Place Order
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}