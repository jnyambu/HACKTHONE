import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Users, DollarSign } from 'lucide-react';
import { Recipe } from '@/data/recipes';

interface RecipeCardProps {
  recipe: Recipe;
  onOrder: (recipe: Recipe) => void;
  onPayment: (recipe: Recipe) => void;
  onViewDetails: (recipe: Recipe) => void;
}

export default function RecipeCard({ recipe, onOrder, onPayment, onViewDetails }: RecipeCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'Advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img 
          src={recipe.image} 
          alt={recipe.name}
          className="w-full h-48 object-cover"
        />
        <Badge className={`absolute top-2 right-2 ${getDifficultyColor(recipe.difficulty)}`}>
          {recipe.difficulty}
        </Badge>
      </div>
      
      <CardHeader>
        <CardTitle className="text-xl font-bold">{recipe.name}</CardTitle>
        <CardDescription className="text-sm text-gray-600">
          {recipe.description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{recipe.cookTime}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{recipe.servings} servings</span>
          </div>
          <div className="flex items-center gap-1">
            <DollarSign className="w-4 h-4" />
            <span className="font-semibold">${recipe.price}</span>
          </div>
        </div>
        
        <div className="flex gap-2 flex-wrap">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onViewDetails(recipe)}
            className="flex-1"
          >
            View Recipe
          </Button>
          <Button 
            variant="default" 
            size="sm" 
            onClick={() => onOrder(recipe)}
            className="flex-1"
          >
            Order Now
          </Button>
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={() => onPayment(recipe)}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
          >
            💳 Insta Pay ${recipe.price}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}