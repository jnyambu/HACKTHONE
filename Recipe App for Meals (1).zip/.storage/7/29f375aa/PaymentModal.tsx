import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { CreditCard, Smartphone, Wallet } from 'lucide-react';
import { Recipe } from '@/data/recipes';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipe: Recipe | null;
}

export default function PaymentModal({ isOpen, onClose, recipe }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'mobile' | 'wallet'>('card');
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePayment = async () => {
    setIsProcessing(true);
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsProcessing(false);
    alert('Payment successful! Your recipe order has been confirmed.');
    onClose();
  };

  if (!recipe) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            💳 Insta Pay - {recipe.name}
          </DialogTitle>
          <DialogDescription>
            Complete your payment quickly and securely
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="bg-gray-50 p-3 rounded-lg">
            <div className="flex justify-between items-center">
              <span className="font-medium">{recipe.name}</span>
              <span className="font-bold text-lg">${recipe.price}</span>
            </div>
            <div className="text-sm text-gray-600">
              Includes recipe, ingredients list, and cooking instructions
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-3">
            <Label className="text-base font-medium">Choose Payment Method</Label>
            
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant={paymentMethod === 'card' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setPaymentMethod('card')}
                className="flex flex-col items-center gap-1 h-16"
              >
                <CreditCard className="w-5 h-5" />
                <span className="text-xs">Card</span>
              </Button>
              
              <Button
                variant={paymentMethod === 'mobile' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setPaymentMethod('mobile')}
                className="flex flex-col items-center gap-1 h-16"
              >
                <Smartphone className="w-5 h-5" />
                <span className="text-xs">Mobile</span>
              </Button>
              
              <Button
                variant={paymentMethod === 'wallet' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setPaymentMethod('wallet')}
                className="flex flex-col items-center gap-1 h-16"
              >
                <Wallet className="w-5 h-5" />
                <span className="text-xs">Wallet</span>
              </Button>
            </div>
          </div>
          
          {paymentMethod === 'card' && (
            <div className="space-y-3">
              <div>
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input id="cardNumber" placeholder="1234 5678 9012 3456" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="expiry">Expiry</Label>
                  <Input id="expiry" placeholder="MM/YY" />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV</Label>
                  <Input id="cvv" placeholder="123" />
                </div>
              </div>
            </div>
          )}
          
          {paymentMethod === 'mobile' && (
            <div className="space-y-3">
              <div>
                <Label htmlFor="phoneNumber">Phone Number</Label>
                <Input id="phoneNumber" placeholder="+1 (555) 123-4567" />
              </div>
              <div className="text-sm text-gray-600">
                We'll send a payment link to your mobile device
              </div>
            </div>
          )}
          
          {paymentMethod === 'wallet' && (
            <div className="space-y-3">
              <div className="text-center py-4">
                <Wallet className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                <div className="text-sm text-gray-600">
                  Connect your digital wallet to complete payment
                </div>
              </div>
            </div>
          )}
          
          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button 
              onClick={handlePayment} 
              disabled={isProcessing}
              className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              {isProcessing ? 'Processing...' : `Pay $${recipe.price}`}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}