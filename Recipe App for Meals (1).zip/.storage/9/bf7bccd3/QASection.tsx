import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, Send } from 'lucide-react';
import { Recipe } from '@/data/recipes';

interface QASectionProps {
  recipe: Recipe;
}

export default function QASection({ recipe }: QASectionProps) {
  const [newQuestion, setNewQuestion] = useState('');
  const [userEmail, setUserEmail] = useState('');

  const handleSubmitQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (newQuestion.trim()) {
      alert('Thank you for your question! We\'ll get back to you within 24 hours.');
      setNewQuestion('');
      setUserEmail('');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            Frequently Asked Questions
          </CardTitle>
          <CardDescription>
            Common questions about {recipe.name}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {recipe.faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Ask a Question</CardTitle>
          <CardDescription>
            Have a specific question about this recipe? Ask our cooking experts!
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmitQuestion} className="space-y-4">
            <div>
              <Input
                type="email"
                placeholder="Your email address"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                required
              />
            </div>
            <div>
              <Textarea
                placeholder="What would you like to know about this recipe?"
                value={newQuestion}
                onChange={(e) => setNewQuestion(e.target.value)}
                required
                className="min-h-[100px]"
              />
            </div>
            <Button type="submit" className="w-full">
              <Send className="w-4 h-4 mr-2" />
              Submit Question
            </Button>
          </form>
          
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="secondary">💡 Beginner Tip</Badge>
            </div>
            <p className="text-sm text-gray-700">
              New to cooking? Don't worry! Our recipes are designed with beginners in mind. 
              Each step is explained clearly, and we're here to help if you get stuck.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}