export interface Recipe {
  id: string;
  name: string;
  image: string;
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  cookTime: string;
  servings: number;
  price: number;
  ingredients: string[];
  instructions: string[];
  tips: string[];
  faqs: { question: string; answer: string }[];
}

export const recipes: Recipe[] = [
  {
    id: 'chicken-biryani',
    name: 'Chicken Biryani',
    image: 'https://images.unsplash.com/photo-1563379091339-03246963d51a?w=500&h=400&fit=crop',
    description: 'Aromatic and flavorful chicken biryani with perfectly spiced rice and tender chicken pieces.',
    difficulty: 'Intermediate',
    cookTime: '90 minutes',
    servings: 4,
    price: 24.99,
    ingredients: [
      '2 cups Basmati rice',
      '1 kg chicken, cut into pieces',
      '2 large onions, sliced',
      '1 cup yogurt',
      '2 tbsp ginger-garlic paste',
      '1 tsp red chili powder',
      '1/2 tsp turmeric powder',
      '1 tsp garam masala',
      '4-5 green cardamom',
      '2 bay leaves',
      '1 cinnamon stick',
      'Salt to taste',
      '4 tbsp ghee',
      'Fresh mint leaves',
      'Fresh coriander leaves'
    ],
    instructions: [
      'Soak basmati rice for 30 minutes, then drain.',
      'Marinate chicken with yogurt, ginger-garlic paste, red chili powder, turmeric, and salt for 30 minutes.',
      'Deep fry sliced onions until golden brown and crispy. Set aside.',
      'In the same oil, cook marinated chicken until 80% done.',
      'Boil water with whole spices, add rice and cook until 70% done.',
      'Layer the rice over chicken, sprinkle fried onions, mint, and coriander.',
      'Cover and cook on high heat for 3-4 minutes, then reduce heat and cook for 45 minutes.',
      'Let it rest for 10 minutes before serving.'
    ],
    tips: [
      'Use aged basmati rice for better texture',
      'Don\'t overcook the rice in the first step',
      'Let the biryani rest after cooking for best flavor'
    ],
    faqs: [
      {
        question: 'Can I use chicken thighs instead of whole chicken?',
        answer: 'Yes! Chicken thighs work great and stay more tender. Adjust cooking time accordingly.'
      },
      {
        question: 'How do I prevent the rice from sticking?',
        answer: 'Make sure to soak the rice properly and don\'t overcook it in the first boiling step.'
      },
      {
        question: 'Can I make this vegetarian?',
        answer: 'Absolutely! Replace chicken with vegetables like potatoes, cauliflower, and peas.'
      }
    ]
  },
  {
    id: 'blueberry-cake',
    name: 'Blueberry Cake',
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500&h=400&fit=crop',
    description: 'Moist and fluffy blueberry cake bursting with fresh berries and topped with a light glaze.',
    difficulty: 'Beginner',
    cookTime: '60 minutes',
    servings: 8,
    price: 18.99,
    ingredients: [
      '2 cups all-purpose flour',
      '1 1/2 cups fresh blueberries',
      '3/4 cup sugar',
      '1/2 cup butter, softened',
      '2 large eggs',
      '1 cup milk',
      '2 tsp baking powder',
      '1/2 tsp salt',
      '1 tsp vanilla extract',
      '2 tbsp flour (for coating berries)',
      'Powdered sugar for dusting'
    ],
    instructions: [
      'Preheat oven to 350°F (175°C). Grease a 9-inch round cake pan.',
      'Toss blueberries with 2 tbsp flour to prevent sinking.',
      'Cream butter and sugar until light and fluffy.',
      'Beat in eggs one at a time, then add vanilla.',
      'In a separate bowl, whisk together flour, baking powder, and salt.',
      'Alternately add dry ingredients and milk to butter mixture.',
      'Gently fold in floured blueberries.',
      'Pour batter into prepared pan and bake for 45-50 minutes.',
      'Cool completely before removing from pan. Dust with powdered sugar.'
    ],
    tips: [
      'Don\'t overmix the batter to keep the cake tender',
      'Coating berries in flour prevents them from sinking',
      'Test doneness with a toothpick in the center'
    ],
    faqs: [
      {
        question: 'Can I use frozen blueberries?',
        answer: 'Yes, but don\'t thaw them first. Use them straight from frozen and toss with flour.'
      },
      {
        question: 'How do I store leftover cake?',
        answer: 'Cover and store at room temperature for 2 days, or refrigerate for up to a week.'
      },
      {
        question: 'Can I make this as cupcakes?',
        answer: 'Yes! Divide batter among 12 cupcake liners and bake for 18-22 minutes.'
      }
    ]
  },
  {
    id: 'orange-cake',
    name: 'Orange Cake',
    image: 'https://images.unsplash.com/photo-1571115764595-644a1f56a55c?w=500&h=400&fit=crop',
    description: 'Zesty orange cake with fresh orange juice and zest, topped with a creamy orange glaze.',
    difficulty: 'Beginner',
    cookTime: '55 minutes',
    servings: 10,
    price: 16.99,
    ingredients: [
      '2 1/4 cups all-purpose flour',
      '1 1/2 cups sugar',
      '1/2 cup butter, softened',
      '3 large eggs',
      '1 cup fresh orange juice',
      '2 tbsp orange zest',
      '1 cup sour cream',
      '2 tsp baking powder',
      '1/2 tsp baking soda',
      '1/2 tsp salt',
      '1 tsp vanilla extract',
      'For glaze: 1 cup powdered sugar, 3 tbsp orange juice'
    ],
    instructions: [
      'Preheat oven to 325°F (165°C). Grease a bundt pan thoroughly.',
      'Cream butter and sugar until light and fluffy.',
      'Beat in eggs one at a time, then add vanilla and orange zest.',
      'In a separate bowl, whisk together flour, baking powder, baking soda, and salt.',
      'Alternately add dry ingredients and orange juice to butter mixture.',
      'Fold in sour cream until just combined.',
      'Pour batter into prepared bundt pan.',
      'Bake for 50-55 minutes until golden and a toothpick comes out clean.',
      'Cool in pan for 10 minutes, then turn out onto wire rack.',
      'For glaze: whisk powdered sugar and orange juice until smooth. Drizzle over cooled cake.'
    ],
    tips: [
      'Use fresh orange juice and zest for best flavor',
      'Don\'t skip the sour cream - it makes the cake extra moist',
      'Make sure the cake is completely cool before glazing'
    ],
    faqs: [
      {
        question: 'Can I use a regular cake pan instead of bundt?',
        answer: 'Yes! Use two 9-inch round pans and reduce baking time to 25-30 minutes.'
      },
      {
        question: 'How long does this cake stay fresh?',
        answer: 'Covered at room temperature, it stays fresh for 3-4 days.'
      },
      {
        question: 'Can I freeze this cake?',
        answer: 'Yes! Wrap tightly and freeze for up to 3 months. Thaw overnight before serving.'
      }
    ]
  }
];