# Recipe App MVP Todo

## Core Features to Implement:
1. **Recipe Display Component** - Show 3 meals with images and details
2. **Payment Integration** - Insta send style payment button
3. **Order Box** - Functional ordering system
4. **Q&A Section** - Questions and answers for each recipe
5. **Beginner-friendly UI** - Simple, clean interface

## Files to Create:
1. `src/pages/Index.tsx` - Main homepage with recipe cards
2. `src/components/RecipeCard.tsx` - Individual recipe display component
3. `src/components/PaymentModal.tsx` - Payment processing modal
4. `src/components/OrderModal.tsx` - Order placement modal
5. `src/components/QASection.tsx` - Questions and answers component
6. `src/data/recipes.ts` - Recipe data with images and details
7. `public/assets/images/` - Recipe images (placeholder URLs)

## Implementation Plan:
- Use shadcn/ui components for consistent styling
- Implement modals for payment and ordering
- Add responsive design for mobile-friendly experience
- Include beginner-friendly instructions and tips
- Use placeholder images from Unsplash for food photos